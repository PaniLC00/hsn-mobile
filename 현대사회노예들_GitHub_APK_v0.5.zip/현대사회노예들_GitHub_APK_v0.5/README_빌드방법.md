# 현대 사회의 노예들 APK 프로젝트

## 현재 상태
- WebView 기반 오프라인 앱
- 통합빌드 v0.4 게임 로직 포함
- 행동 결과 중앙 카드, 수치 변화 강조, 진동 피드백 추가
- 제공된 효과음 5개 전부 로컬 자산으로 포함

## APK 만들기
1. Android Studio에서 이 폴더를 연다.
2. Gradle Sync가 끝나면 `Build > Build App Bundle(s) / APK(s) > Build APK(s)`를 누른다.
3. 생성된 디버그 APK는 보통 `app/build/outputs/apk/debug/app-debug.apk`에 생긴다.

## 효과음 연결
- 일반 터치: `assets/audio/touch.mp3`
- 조건 미충족: `assets/audio/error.mp3`
- 돈/스펙 증가: `assets/audio/cash.mp3`
- 큰 성공: `assets/audio/wow.wav`
- 병원/감옥/쿠데타 실패: `assets/audio/bad.mp3`

## 주의
현재 대화 실행 환경에는 Android SDK와 Gradle 빌드 도구가 없어 APK 바이너리는 이곳에서 직접 생성하지 못했다. 프로젝트 자체는 Android Studio에서 바로 열어 빌드하도록 구성했다.
