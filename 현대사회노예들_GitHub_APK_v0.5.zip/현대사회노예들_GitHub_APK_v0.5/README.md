# 현대 사회의 노예들 모바일 독립판

Android WebView 기반 독립판. 게임 HTML/JS와 효과음은 APK 내부 assets에 포함된다.

## 자동 APK 빌드
GitHub Actions의 **Build APK** 워크플로가 push 시 자동 실행된다.

빌드 성공 후:
1. 저장소의 Actions 탭
2. 최신 `Build APK` 실행
3. 아래 Artifacts에서 `HSN-Mobile-debug-apk` 다운로드
4. ZIP을 풀어 `app-debug.apk` 설치

## 효과음
- 병원/감옥/쿠데타 실패: 아이고난 2
- 조건 미충족: 삐삑
- 일반 터치: 뾰옥
- 돈/스펙 획득: 철컥띵
- 큰 성공: 와우
